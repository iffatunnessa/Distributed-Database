create or replace view myview as
select S.id, S.name, R.cgpa
from student S, student_result R
where S.id = R.id;

select * from myview;

