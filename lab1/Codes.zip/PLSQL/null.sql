BEGIN
   NULL;
END;
/
