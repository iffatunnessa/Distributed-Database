set serveroutput on;

declare

begin	
	findDueSupply;
	
end;
/
